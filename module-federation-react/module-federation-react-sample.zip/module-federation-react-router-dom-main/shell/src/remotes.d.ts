declare module 'app1/App1Index';
declare module 'app2/App2Index';