import React from "react";
import "./index.css";
import { Router } from "./routing/Router";

export const App = () => (
  <Router />
);
