export const app1RoutingPrefix = 'app-1';
export const app2RoutingPrefix = 'app-2';